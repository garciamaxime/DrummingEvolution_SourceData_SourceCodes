# Woopecker
R Code for Evolution of Communication Signals in Woodpeckers

This repository contains all of the data and the data analysis and simulation scripts in R that were used for the paper "Evolution of communication signals and information during species radiation" by Garcia et. al

For additional information, please e-mail:

Maxime Garcia, maxime.garcia@ymail.com 
Nicola Mathevon, mathevon@univ-st-etienne.fr 
Frederic Theunissen, theunissen@berkeley.edu

