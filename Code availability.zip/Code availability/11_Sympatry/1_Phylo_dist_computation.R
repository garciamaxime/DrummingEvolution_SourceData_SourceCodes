setwd("../11_Sympatry/")
rm(list=ls())#empty the workspace

library(ape)

# Load data that has the right species order (same as for matrices of acoustic distance and misclassification)
data <- read.csv("Full_Species_data.csv", header=T, row.names = 1)
# Read in the tree (require ape)
tree <-read.nexus(file = 'TreePicidae.txt')

#########################
### Standardizing the tree to unit height. 
# tree$edge.length <- tree$edge.length/max(branching.times(tree))
#########################

# Create distance matrix based on tree:
outputMatrix <-cophenetic.phylo(tree)
# Note: can also work with the function "distTips()" from adephylo package --> tried and gives exactly the same result

# Reorder Matrix
outputMatrix2 <- as.data.frame(outputMatrix)
outputMatrix2 <- outputMatrix2[rownames(data),rownames(data)]

# Now that reordering is ok, attribute name abbreviations to match other matrices
rownames (outputMatrix2) <- data$Species
colnames (outputMatrix2) <- data$Species


# Remove lower half (as for other matrices, data repeated otherwise in upper and lower matrix)
for (X in 1:dim(outputMatrix2)[1]){ # First go through rows
  for (Y in 1:dim(outputMatrix2)[2]){ # then go through columns 
    if (X >= Y){outputMatrix2[X,Y] <- 'NA'} # set one side (in this case the lower) of the diagonal to NAs (two mirroed half-matrices here thus repetition of the same data)
  }
}

write.csv(outputMatrix2, "Phyldist_matrix.csv")

